# Source archives

Use **nebula-source-ec6b797.tar.gz** (Git commit `ec6b797`) for installation and demonstration.
It includes the portable Docker wrappers, bootstrap script, installation guide,
and current regression tests. It excludes submission bundles to avoid nested
copies and contains only committed source, with no local credentials or run data.

`nebula-source-040eb0d.tar.gz` is retained only as the historical snapshot named
in the frozen technical report and presentation. It predates portability fixes
and has machine-specific paths and platform symlinks; do not use it for fresh
installation. The measured RTL, constraints, formal proof and physical results
remain unchanged. The project manifest in `03_RTL_AND_CONSTRAINTS` is also a
historical reference; use the manifest inside the portable archive to run tools.

Start with the package's `README_FIRST.md`. The installation check and offline
regression output for the refreshed archive is in
`../04_PROOFS/tests/portable_source_bootstrap.txt`.
