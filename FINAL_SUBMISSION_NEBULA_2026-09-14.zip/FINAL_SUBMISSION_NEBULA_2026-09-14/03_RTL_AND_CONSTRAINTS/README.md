# RTL deliverable

- `original/nebula_aux_domain.v`: baseline editable RTL.
- `optimized/nebula_aux_domain.v`: accepted equivalent RTL.
- `accepted.patch`: exact change.
- `constraints/ethmac5.sdc`: frozen five-master/five-generated-clock constraints.
- `nebula.project.yaml`: historical project manifest retained with the evidence.
  For execution, use `benchmarks/ethmac5/nebula.project.yaml` inside the portable
  source archive; its tool paths are portable.
- `BENCHMARK_README.md`: qualification and reproduction details.

The full dependency source tree and orchestrator are in
`../05_SOURCE/nebula-source-ec6b797.tar.gz`.

